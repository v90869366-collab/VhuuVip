VhuuVip Web Clip / mobileconfig
================================

This profile is a starter template, not a complete hosted app.
- It installs a Web Clip named VhuuVip pointing to https://example.com/.
- Replace that URL with your own HTTPS-hosted page before installing.
- It includes a Google DNS-over-HTTPS payload. iOS behavior may vary by version and managed DNS policies.
- The key `VhuuVip` is not implemented by the configuration profile itself; it must be implemented in the website HTML/JavaScript.
- The icon is a simple generated V icon because no avatar image was supplied.
- XML profile is unsigned. Review before installing; iOS may show that it is not signed/verified.
